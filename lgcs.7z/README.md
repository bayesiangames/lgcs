# lgcs
Jogos cooperativos na gestão da cadeia de suprimentos
